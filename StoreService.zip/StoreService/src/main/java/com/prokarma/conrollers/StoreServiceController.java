package com.prokarma.conrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prokarma.entity.Order;
import com.prokarma.services.StoreService;

@RestController
public class StoreServiceController {

	@Autowired
	StoreService storeServiceImpl;

	@Autowired
	JmsTemplate jsmTemplate;
	
	@GetMapping("getOrderById/{id}")
	public ResponseEntity<Order> getOrderById(@PathVariable("id") Integer id) {
		Order order = storeServiceImpl.getOrderById(id);
		return new ResponseEntity<Order>(order, HttpStatus.OK);
	}

	@GetMapping("/getAllOrdesr")
	public ResponseEntity<List<Order>> getAllOrdesr() {

		List<Order> listOfOrder = storeServiceImpl.getAllOrders();

		return new ResponseEntity<List<Order>>(listOfOrder, HttpStatus.OK);
	}

	@GetMapping("/pushAllOrdesr")
	public ResponseEntity<String> pushAllOrdesr() {

		jsmTemplate.convertAndSend("all-order", storeServiceImpl.getAllOrders());

		return new ResponseEntity<String>("All Orders sent successfully!!!", HttpStatus.OK);
	}
	
	@PutMapping("/updateOrder")
	public ResponseEntity<Order> updateOrder(@RequestBody Order order) {
		storeServiceImpl.updateOrder(order);
		return new ResponseEntity<Order>(order, HttpStatus.OK);
	}

	@DeleteMapping("removeOrder/{id}")
	public ResponseEntity<Void> deleteArticle(@PathVariable("id") Integer id) {
		storeServiceImpl.deleteOrder(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}

}
