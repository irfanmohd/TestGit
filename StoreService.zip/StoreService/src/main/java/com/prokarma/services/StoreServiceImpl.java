package com.prokarma.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.prokarma.entity.Order;
import com.prokarma.repository.OrderServiceRepository;

@Service
public class StoreServiceImpl implements StoreService {

	@Autowired
	OrderServiceRepository orderRepo;

	@Override
	public void addOrder(Order order) {

		System.out.println("Order Received::::" + order);
		orderRepo.addOrder(order);
	}

	@Override
	public List<Order> getAllOrders() {
		return orderRepo.getAllOrders();
	}

	@Override
	public Order getOrderById(int articleId) {
		Order obj = orderRepo.getOrderById(articleId);
		return obj;
	}

	@Override
	public void updateOrder(Order order) {
		orderRepo.updateOrder(order);
	}

	@Override
	public void deleteOrder(int orderId) {
		orderRepo.deleteOrder(orderId);
	}
}
