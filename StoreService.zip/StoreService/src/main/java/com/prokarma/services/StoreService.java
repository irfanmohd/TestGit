package com.prokarma.services;

import java.util.List;

import com.prokarma.entity.Order;

public interface StoreService {

	public void addOrder(Order order);
	
	public List<Order> getAllOrders();
	
	Order getOrderById(int orderId);
	
	void updateOrder(Order order);
	
    void deleteOrder(int orderId);
	
	

}
