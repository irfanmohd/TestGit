package com.prokarma.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.prokarma.entity.Order;

public class OrderResultSetExtractor implements ResultSetExtractor<List<Order>> {

	@Override
	public List<Order>  extractData(ResultSet rs) throws SQLException, DataAccessException {

		List<Order> list = new ArrayList<Order>();
		while (rs.next()) {
			Order order = new Order();
			order.setOrderID(rs.getInt("order_id"));
			order.setCustomerID(rs.getInt("customer_id"));
			order.setOrderDate(rs.getTimestamp("order_date"));
			order.setItemName(rs.getString("item_name"));
			list.add(order);
		}
		return list;
	}

}