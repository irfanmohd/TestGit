package com.prokarma.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.prokarma.entity.Order;

public class OrderRowMapper implements RowMapper<Order> {
	@Override
	public Order mapRow(ResultSet row, int rowNum) throws SQLException {
	
		Order order = new Order();
		order.setOrderID(row.getInt("order_id"));
		order.setCustomerID(row.getInt("customer_id"));
		order.setOrderDate(row.getTimestamp("order_date"));
		order.setItemName(row.getString("item_name"));
		return order;
	}

}
