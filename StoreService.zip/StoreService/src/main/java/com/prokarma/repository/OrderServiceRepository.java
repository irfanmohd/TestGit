package com.prokarma.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.prokarma.entity.Order;
import com.prokarma.mappers.OrderResultSetExtractor;
import com.prokarma.mappers.OrderRowMapper;

@Repository
public class OrderServiceRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	 NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	/**
	 * Adding an order into database table
	 * 
	 * @param order
	 * @return
	 */
	public int addOrder(Order order) {
		
		//using place holders
		/*
		 * String insertQuery =
		 * "INSERT INTO product_db.ORDER(customer_id,order_date,item_name) VALUES(?,?,?)"
		 * ; int i = 0; try { i = jdbcTemplate.update(insertQuery, new Object[] {
		 * order.getCustomerID(), order.getOrderDate(), order.getItemName() }); } catch
		 * (DataAccessException e) { System.out.println(e.getMessage()); } return i;
		 */
		
		//using named parameter
		String sql = "INSERT INTO product_db.ORDER " +
				"(customer_id, order_date, item_name) VALUES (:custId, :orderDate, :itemname)";
				
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("custId", order.getCustomerID());
			parameters.put("orderDate", order.getOrderDate());
			parameters.put("itemname", order.getItemName());
				
			return namedParameterJdbcTemplate.update(sql, parameters);
			
			
	}

	/**
	 * Getting all Items from table
	 * 
	 * @return
	 */
	public List<Order> getAllOrders() {
		String selectQuery = "select order_id,customer_id,order_date, item_name from product_db.Order";
		//1st way
		/*
		 * List<Order> listOfOrders = jdbcTemplate.query(selectQuery, (result, rowNum)
		 * -> new Order(result.getInt("order_id"), result.getInt("customer_id"),
		 * result.getDate("order_date"), result.getString("item_name")));
		 * 
		 */
		//2nd way using 
		 List<Order> listOfOrders =  jdbcTemplate.query(selectQuery,new OrderResultSetExtractor());
		
		
	     return listOfOrders;
		 	}

	/**
	 * Method to get order based on id
	 * 
	 * @param orderId
	 * @return
	 */
	public Order getOrderById(int orderId) {
		//using place holders
		/*
		 * String sql =
		 * "SELECT order_id, customer_id, order_date, item_name FROM product_db.Order WHERE order_id = ?"
		 * ; RowMapper<Order> rowMapper = new OrderRowMapper(); Order order =
		 * jdbcTemplate.queryForObject(sql, rowMapper, orderId); return order;
		 */
		
		//2nd way using named parameter
		 String sql = "SELECT order_id, customer_id, order_date, item_name FROM product_db.Order WHERE order_id = :orderId";
		Map<String, Integer> parameters = new HashMap<String, Integer>();
		parameters.put("orderId", orderId);
		return (Order) namedParameterJdbcTemplate.queryForObject(sql, parameters, new OrderRowMapper());
	}

	/**
	 * Method to update order
	 * 
	 * @param order
	 */
	public void updateOrder(Order order) {
		String sql = "UPDATE product_db.order SET item_name=? WHERE order_id=?";
		jdbcTemplate.update(sql, order.getItemName(), order.getOrderID());
	}

	/**
	 * Method to delete order
	 * 
	 * @param orderId
	 */
	public void deleteOrder(int orderId) {
		String sql = "DELETE FROM product_db.order WHERE order_id=?";
		int i = jdbcTemplate.update(sql, orderId);
		System.out.println("i-------->" + i);
	}
}
