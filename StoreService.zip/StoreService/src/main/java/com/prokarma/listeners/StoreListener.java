package com.prokarma.listeners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.prokarma.entity.Order;
import com.prokarma.services.StoreServiceImpl;

@Component
public class StoreListener {

		 
	@Autowired
	StoreServiceImpl serviceImpl;

	@JmsListener(destination = "order-queue", containerFactory = "jsaFactory")
	public void receiveMessage(Order order) {
		System.out.println("Received::" + order);
		serviceImpl.addOrder(order);
	}
}
