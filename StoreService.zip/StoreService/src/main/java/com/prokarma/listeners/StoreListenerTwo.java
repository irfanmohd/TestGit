package com.prokarma.listeners;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.prokarma.entity.Order;

@Component
public class StoreListenerTwo {

	//@JmsListener(destination = "simple_queue", containerFactory = "jsaFactory")
	public void receiveMessage(Order order) {
		System.out.println("Received2::" + order);

	}

}
