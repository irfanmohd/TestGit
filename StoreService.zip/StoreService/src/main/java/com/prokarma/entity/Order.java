package com.prokarma.entity;

import java.io.Serializable;
import java.util.Date;

public class Order implements Serializable {

	private int orderID;
	private int customerID;
	private Date orderDate;
	private String itemName;

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public Order(int orderID, int customerID, Date orderDate, String itemName) {
		super();
		this.orderID = orderID;
		this.customerID = customerID;
		this.orderDate = orderDate;
		this.itemName = itemName;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Order() {
		super();
	}

	@Override
	public String toString() {
		return "Order [orderID=" + orderID + ", customerID=" + customerID + ", orderDate=" + orderDate + ", itemName="
				+ itemName + "]";
	}

}
