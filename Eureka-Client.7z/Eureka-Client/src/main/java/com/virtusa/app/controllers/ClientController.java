package com.virtusa.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@RestController
public class ClientController {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	private DiscoveryClient discoveryClient;

	@Autowired
	private LoadBalancerClient loadBalancer;
	
	@GetMapping("/")
	public String invokeService() {
		String html = null;
		
		//With out load balancing (Need!!) eureka.client.fetchRegistry=true and rest template not annotate @loadbalanced
		/*List<ServiceInstance> instances = this.discoveryClient.getInstances("eureka-service");
		ServiceInstance serviceInstance=instances.get(0);*/
		
		//Calling service without discovery service (Resttemplate must be annotate @loadbalance)
		//String baseUrl="http://eureka-service/demo";
		
		//Load balancing with out @RibbonClient (Resttemplate must not be annotate @loadbalance)		
		ServiceInstance serviceInstance=this.loadBalancer.choose("eureka-service");
		
		System.out.println(serviceInstance.getUri());
		
		String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/demo";
		
		/*baseUrl = baseUrl + "/demo";
		if (instances == null || instances.isEmpty()) {
			return "No instances for service: " + "eureka-service";
		}
		for (ServiceInstance serviceInstances : instances) {
			html += "<h3>Instance :" + serviceInstances.getUri() + "</h3>";
		}*/

		return restTemplate.getForObject(baseUrl, String.class);
	}

	@Bean
	//@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
