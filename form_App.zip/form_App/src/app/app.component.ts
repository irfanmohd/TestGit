import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
  
})
export class AppComponent {
  
  constructor(private http:HttpClient){

  }
    // @ViewChild('f', { static: true })
    // signupForm: NgForm;
    defaultQuestion='pet';
    answer='';
    genders=['Male','Female'];
    submitted = false;
    user ={
      username:'',
      Email: '',
      SecretQuestion: '',
      Answer:'',
      Gender:''
    }

  // onSubmit(form:NgForm){
  //   console.log(form)
  // }

   onSubmit(signupForm:NgForm){
    this.submitted = true;
     console.log(signupForm);
    this.user.username = signupForm.value.username;
    this.user.Email = signupForm.value.email;
    this.user.SecretQuestion = signupForm.value.secret;
    this.user.Answer = signupForm.value.questionAnser;
    this.user.Gender = signupForm.value.gender;
    // calling http request
    this.http.post(
      "https://database-4f78f.firebaseio.com/posts.json",
      this.user).subscribe(responeData=>{
        console.log(responeData);
      });
}
  

}
