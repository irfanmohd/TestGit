package com.datastructure;

public class User {

	private int id;

	private User(int id) {
		super();
		this.id = id;
	}
}
