package com.datastructure;

public class Parent {

	
	public Parent get() {
		
		return this;
	}
}


