package com.datastructure;

public class Child2 {

}
