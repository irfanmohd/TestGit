package com.java8.lamdaexpressions;

public interface LamdaInterace2 {

	public int add(int a,int b);
}
