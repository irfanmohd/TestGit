package com.java8.lamdaexpressions;

public interface LamdaInterace {
	
	public void m1();

}
