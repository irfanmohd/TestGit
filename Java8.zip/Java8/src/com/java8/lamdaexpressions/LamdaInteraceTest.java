package com.java8.lamdaexpressions;

public class LamdaInteraceTest {

	public static void main(String args[]) {
		
		LamdaInterace li = ()->System.out.println("lambda expression with no parameter");
		
		li.m1();
	}
}
