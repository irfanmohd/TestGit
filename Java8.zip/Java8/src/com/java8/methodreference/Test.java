package com.java8.methodreference;

public class Test {
	
	public static void m2() {
		System.out.println("M2() method of test class::::");
	}
	
	public static void main(String args[]) {
		
		//Using lambda expression
		/*
		 * Blessing bs= ()->{ System.out.println("m1() implementation:::"); };
		 */
		
		//Using method reference
		Blessing bs = Test::m2;
	
		bs.m1();
		
		
		
		
	}

}
