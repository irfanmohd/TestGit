package com.java8.methodreference;

public interface Blessing {
	
	public void m1();

}
