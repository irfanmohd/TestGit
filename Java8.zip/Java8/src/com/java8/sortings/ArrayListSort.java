package com.java8.sortings;

import java.util.ArrayList;
import java.util.List;

public class ArrayListSort {
	
	public static void main(String[] args) {
        Employee emp1 = new Employee(123,"uohn Doe");
        Employee emp2 = new Employee(231,"Te Lobo");
        Employee emp3 = new Employee(231,"Dave Mathias");
        
        List<Employee> empList = new ArrayList<Employee>();
        empList.add(emp1);
        empList.add(emp2);
        empList.add(emp3);
        
        empList.sort((o1, o2) -> o2.getEmpName().compareTo(o1.getEmpName()));
 
        System.out.println("Sorted List" + empList);
         
   
    }

}
