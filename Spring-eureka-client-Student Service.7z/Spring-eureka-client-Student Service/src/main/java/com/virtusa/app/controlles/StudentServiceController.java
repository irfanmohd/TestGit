package com.virtusa.app.controlles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.app.entities.School;
import com.virtusa.app.entities.Student;

@RestController
public class StudentServiceController {
	
	private static Map<String, List<Student>> schooDB = new HashMap<String, List<Student>>();

	static {
		schooDB = new HashMap<String, List<Student>>();

		List<Student> lst = new ArrayList<Student>();
		Student std = new Student("Sajal", "Class IV");
		lst.add(std);
		std = new Student("Lokesh", "Class V");
		lst.add(std);

		schooDB.put("abcschool", lst);

		lst = new ArrayList<Student>();
		std = new Student("Kajal", "Class III");
		lst.add(std);
		std = new Student("Sukesh", "Class VI");
		lst.add(std);

		schooDB.put("xyzschool", lst);

	}

	@RequestMapping(value = "/getStudentDetailsForSchool/{schoolname}", method = RequestMethod.GET)
	public ResponseEntity<List<Student>> getStudents(@PathVariable String schoolname) {
		System.out.println("Getting Student details for " + schoolname);

		List<Student> studentList = schooDB.get(schoolname);
		if (studentList == null) {
			studentList = new ArrayList<Student>();
			Student std = new Student("Not Found", "N/A");
			studentList.add(std);
		}
		return new ResponseEntity<List<Student>>(studentList,HttpStatus.ACCEPTED);
	}

	
	
	@RequestMapping(value = "/addStudentDetailsForSchool", method = RequestMethod.POST)
	public ResponseEntity<String> getStudents(@RequestBody Student student) {
		System.out.println("Student Name" + student.getName());
		System.out.println("Class Name" + student.getClassName());
		
		
		return new ResponseEntity<String>("Student added succesfully",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updateStudentDetailsForSchool", method = RequestMethod.PUT)
	public ResponseEntity<Student> updateStudents(@RequestBody Student student) {

		Student update = new Student();
		if(student.getName().equalsIgnoreCase("irfan"))
		{
			update.setName("maddy");
			update.setClassName(student.getClassName());
		}
		
		
		return new ResponseEntity<Student>(update,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getSchoolDetails/{studentName}", method = RequestMethod.GET)
	public ResponseEntity<School> getSchool(@PathVariable String studentName) {
		System.out.println("Getting School details for " + studentName);

		School school = null;
		if (studentName.equalsIgnoreCase("Sachin")) {

			school = new School("Infinite", "Bangalore");

		}

		return new ResponseEntity<School>(school, HttpStatus.OK);
	}

}
