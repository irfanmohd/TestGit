import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { UsersRoutingModel } from "./users-routing.model";


@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        UsersRoutingModel
    ],
    providers: []


})
export class UsersModule {

    constructor() {
        console.log("user module is loaded.....");
    }
}