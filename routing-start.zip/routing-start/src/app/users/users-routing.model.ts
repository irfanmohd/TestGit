import {  RouterModule, Routes } from "@angular/router";
import { UsersComponent } from "./users.component";
import { UserComponent } from "./user/user.component";
import { NgModule } from "@angular/core";


const userRoutes : Routes = [
    {
        path: 'users',
        component: UsersComponent,
        children: [
          {
            path: ':id/:name',
            component: UserComponent
          }
        ]
      }
];
@NgModule({
    imports:[
        RouterModule.forChild(userRoutes)
    ],
    exports:[RouterModule]
})
export class UsersRoutingModel {
    
}