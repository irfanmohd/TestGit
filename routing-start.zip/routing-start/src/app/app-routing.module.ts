import { HomeComponent } from "./home/home.component";
import { Routes, RouterModule, PreloadAllModules } from "@angular/router";
import { UsersComponent } from "./users/users.component";
import { UserComponent } from "./users/user/user.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { NgModule } from "@angular/core";


const appRoutes: Routes = [
  {
    path: 'servers',
    loadChildren:'./servers/servers.module#ServersModule'
  },
    {
      path: '',
      component: HomeComponent
    },
    {
      path:'not-found',
      component:PageNotFoundComponent
    },
    {
      path:'**',
      redirectTo:'/not-found',
      pathMatch: 'full'
    }
  
  ];
  @NgModule({
    imports: [
      RouterModule.forRoot(appRoutes,{
        preloadingStrategy:PreloadAllModules
      })
    ],
    exports:[RouterModule]
  })
export class AppRoutingModule{
    

} 