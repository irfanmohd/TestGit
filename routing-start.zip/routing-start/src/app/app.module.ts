import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { UserComponent } from './users/user/user.component';
import { ServersService } from './servers/servers.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AuthGuard } from './auth-guard.service';
import { AuthService } from './auth.service';
import { AppRoutingModule } from './app-routing.module';
import { ServersModule } from './servers/servers.module';
import {UsersModule} from './users/users.module';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UsersComponent,
    UserComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    // ServersModule,
    UsersModule,
    AppRoutingModule
    
  ],
  providers: [ServersService,AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(){
    console.log("Home Module is loaded..................");
  }
 }
