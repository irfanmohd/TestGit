import { EditServerComponent } from "./edit-server/edit-server.component";
import { ServersComponent } from "./servers.component";
import { ServerComponent } from "./server/server.component";
import { NgModule } from "@angular/core";
import { ServersRoutingModule } from "./servers-routing.module";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";

@NgModule({
    declarations: [
        ServersComponent,
        EditServerComponent,
        ServerComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ServersRoutingModule
    ]   
})
export class ServersModule {
    constructor() {
        console.log("Server module is loaded.............");
    }
}