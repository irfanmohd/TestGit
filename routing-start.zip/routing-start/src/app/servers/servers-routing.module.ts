import { RouterModule, Routes } from "@angular/router";
import { NgModule } from "@angular/core";
import { ServerComponent } from "./server/server.component";
import { EditServerComponent } from "./edit-server/edit-server.component";
import { ServersComponent } from "./servers.component";

const serversRoutes: Routes = [
    {
      path: '',
      //canActivate:[AuthGuard],
      //canActivateChild:[AuthGuard],
      component: ServersComponent,
      children: [
        {
          path: ':id/edit',
          component: EditServerComponent
        },
        {
          path: ':id',
          component: ServerComponent
        }
      ]
    }  
  ];
 @NgModule({
    imports: [
      RouterModule.forChild(serversRoutes)
    ],
    exports:[RouterModule]
  })
export class ServersRoutingModule {


}