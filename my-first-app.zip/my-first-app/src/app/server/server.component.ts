import { Component } from '@angular/core';


@Component({
selector:'app-server',
templateUrl:'./server.component.html'
})
export class ServerComponent{
    
    serverId:number=1;
    severStatus='online';
    
   

    getServerStatus()
    {
        return this.severStatus =  Math.random()>0.5?"online":"offline";
    }


    getColor(){

        return this.severStatus==="online"?"green":"yellow"
    }

}

  