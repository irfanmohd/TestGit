import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent  {

  allowedNewServer =  false;
  serverCreatedStatus = ' No server was created';
  servername = 'text';
  serverCreate = false;

  constructor(){
    setTimeout(() => {
        this.allowedNewServer=true;
    }, 2000);
}



  onCreatedServer(){
    this.serverCreate = true;
   this.serverCreatedStatus='Server is created';
 }

 onUpateServerName(event:Event){
  this.servername = (<HTMLInputElement>event.target).value;
 }
  
}
