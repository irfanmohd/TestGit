package com.virtusa.app.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.virtusa.app.entities.Student;



@RestController
public class SchoolServiceController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@Value("${student.service}")
	private String studentService;

	/*@RequestMapping(value = "/getSchoolDetails/{schoolname}", method = RequestMethod.GET)
	public ResponseEntity<List<Student>> getStudents(@PathVariable String schoolname) 
	{
		System.out.println("Getting School details for " + schoolname);
		String uri = "http://student-service/getStudentDetailsForSchool/"+schoolname;
		List  response = null;
		
		try {
		   response = restTemplate.exchange(uri,HttpMethod.GET,null,List.class).getBody();

			System.out.println("Response Received as " + response);

			
		}catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		
		return  new ResponseEntity<List<Student>>(response, HttpStatus.OK);
	}
*/

	@RequestMapping(value = "/updateStudentDetailsForSchool", method = RequestMethod.PUT)
	public ResponseEntity<Student> updateStudents(@RequestBody Student student) throws IOException 
	{
		System.out.println("studentService---->"+studentService);
		
		/*List<ServiceInstance> instances=discoveryClient.getInstances(studentService);
		ServiceInstance serviceInstance=instances.get(0);
		
		String baseUrl=serviceInstance.getUri().toString();
		System.out.println("baseurl---------->"+baseUrl);
		
		baseUrl=baseUrl+"/updateStudentDetailsForSchool";*/
		
		String baseUrl="http://student-service/updateStudentDetailsForSchool";
		
		ResponseEntity<Student> response = null;
		
		try {
			HttpEntity<?> entity = new HttpEntity<>(student,getHeaders());
		   response = restTemplate.exchange(baseUrl,HttpMethod.PUT,entity,Student.class);

			System.out.println("Response Received as " + response);

			
		}catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		
		return response;
	}

	@RequestMapping(value = "/addStudentDetailsForSchool", method = RequestMethod.POST)
	public ResponseEntity<String> getStudents(@RequestBody Student student) {
		
		String uri = "http://student-service/addStudentDetailsForSchool";
		String response = null;
		
		try {
		
		   response = restTemplate.postForObject(uri,student,String.class);

			System.out.println("Response Received as " + response);

			
		}catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<String>("Student added succesfully",HttpStatus.OK);
	}
	
	private  HttpHeaders getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return headers;
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	//Added for Zuul api
	
	@RequestMapping(value = "/getStudentDetails/{schoolname}", method = RequestMethod.GET)
	public ResponseEntity<List<Student>> getStudents(@PathVariable String schoolname) 
	{
		System.out.println("Getting School details for " + schoolname);
		List<Student> response = new ArrayList<>();

		if (schoolname.equalsIgnoreCase("abc")) {

			Student std = new Student("Sachin", "B.Tech");
			response.add(std);
			std = new Student("Lokesh", "M.Tech");
			response.add(std);

		}

		return new ResponseEntity<List<Student>>(response, HttpStatus.OK);
	}

	

}
