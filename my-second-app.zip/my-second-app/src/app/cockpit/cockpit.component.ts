import { Component, OnInit, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.css']
})
export class CockpitComponent implements OnInit {

  // newServerName = '';
  // newServerContent = '';
  @Output()
  serverCreated = new EventEmitter<{serverName:string,serverContent:string}>();
  @Output()
  blueprintCreated= new EventEmitter<{serverName:string,serverContent:string}>();

  @ViewChild('serverContentInput',{static: true})  serverContentInput:ElementRef;

  constructor() { }

  ngOnInit() {
  }

  onAddServer(serverInpurName){
    
    this.serverCreated.emit({
      serverName:serverInpurName.value,
      serverContent: this.serverContentInput.nativeElement.value
    });
  }

 
  onAddBlueprint(serverInpurName:HTMLInputElement){
    this.blueprintCreated.emit({
      serverName:serverInpurName.value,
      serverContent: this.serverContentInput.nativeElement.value
    });
  }
}
