package com.prokarma.conrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prokarma.entity.*;
import com.prokarma.services.ClientServiceImpl;

@RestController
public class ClientControllers {
	
	@Autowired
	ClientServiceImpl client;
	/*
	 * Controller to create new order.
	 */
	@PostMapping("/addOrder")
    public void create(@RequestBody Order order) {
		
         client.addOrder(order);
    }

}
