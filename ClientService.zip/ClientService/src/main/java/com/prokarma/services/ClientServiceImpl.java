package com.prokarma.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.prokarma.entity.Order;

@Service
public class ClientServiceImpl implements ClientService {

	@Value("${spring.jms.destination}")
	private String orderQueue;
	
	

	@Autowired
	private JmsTemplate jmsTemplate;

	/*
	 * @Autowired private Queue queue;
	 */

	@Override
	public void addOrder(Order order) {
		order.setOrderDate(new Date());		
		jmsTemplate.convertAndSend(orderQueue, order);
		System.out.println("Message send::::" + order);
	}

}
