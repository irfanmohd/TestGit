package com.prokarma.services;

import com.prokarma.entity.Order;

public interface ClientService {
	 
	    public void addOrder(Order order);

}
