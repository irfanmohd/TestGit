package com.prokarma.listeners;

import java.util.List;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.prokarma.entity.Order;

@Component
public class ClientListener {

	
	@JmsListener(destination = "all-order", containerFactory = "jsaFactory")
	public void receiveMessage(List<Order> order) {
		System.out.println("Received all Order ::" + order);
		
	}
}
