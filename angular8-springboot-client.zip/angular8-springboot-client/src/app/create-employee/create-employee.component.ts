import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  employee: Employee = new Employee();
  submitted = false;
  countries = [
    {
      id: '8f8c6e98',
      name: 'USA',
      code: 'USD'
    },
    {
      id: '169fee1a',
      name: 'Canada',
      code: 'CAD'
    },
    {
      id: '3953154c',
      name: 'UK',
      code: 'GBP'
    },
    {
      id: '68c61e29',
      name:"India",
      code:'IND'
    }


  ]

  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit() {
    
  }

  employees(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  save() {
   
    this.employeeService.createEmployee(this.employee)
      .subscribe(
        data => console.log(data),
        error => console.log(error));
    this.employee = new Employee();
    this.gotoList();
  }

  onSubmit(signupForm: NgForm) {
    console.log(signupForm);
    

    if (signupForm.valid) {
      console.log("$$$$" + JSON.stringify(this.employee));
      this.submitted = true;
      this.save();
    }
    else {
      alert("Please enter all the mandatory fields");
      return false;

    }

  }

  gotoList() {
    this.router.navigate(['/employees']);
  }
}
