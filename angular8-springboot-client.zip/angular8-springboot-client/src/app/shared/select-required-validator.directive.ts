
import { Directive, Input } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
    selector: '[appSelectDirective]',
    providers: [{ provide: NG_VALIDATORS, 
                  useExisting: SelectRequiredDirective,
                  multi: true }]
})
export class SelectRequiredDirective implements Validator {
    @Input('appSelectDirective') selectedvalue:string;

    validate(control: AbstractControl){
      return  control.value === this.selectedvalue ?{'defaultSelected':true}:null;
    }
}