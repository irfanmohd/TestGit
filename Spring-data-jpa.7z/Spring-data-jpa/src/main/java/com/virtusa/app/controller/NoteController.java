package com.virtusa.app.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.app.entities.Note;
import com.virtusa.app.repository.NoteRepository;
import com.virtusa.app.vo.NoteVO;

@RestController
public class NoteController {

	
	 @Autowired
	  NoteRepository noteRepository;
	 
	@GetMapping("/notes")
	public List<Note> getAllNotes() {
	    return noteRepository.findAll();
	}
	
	@PostMapping("/addNote")
	public NoteVO addNote(@RequestBody Note note) {
		
		Note response = noteRepository.save(note);
		NoteVO noteVO = new NoteVO();
		noteVO.setId(response.getId());
		noteVO.setTitle(response.getTitle());
		noteVO.setContent(response.getContent());
		noteVO.setCreatedAt(convertMilisecondsToDate(response.getCreatedAt()));
		noteVO.setUpdatedAt(convertMilisecondsToDate(response.getUpdatedAt()));
	    return noteVO;
	}

	private String convertMilisecondsToDate(Date createdAt) {
		
		
			System.out.println("createdAt-->"+createdAt);
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");  
		    String strDate= formatter.format(createdAt);
		    System.out.println("strDate-->"+strDate);
			return strDate;  
		    
	}
	
	
	
}
